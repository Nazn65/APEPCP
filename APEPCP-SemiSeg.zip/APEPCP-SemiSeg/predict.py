import torch
import torch.nn.functional as F
import yaml
from torch.utils.data import DataLoader
from model.unet_corr import UNet
from dataset.acdc import ACDCDataset
import numpy as np
import argparse
import os


def load_model(model, checkpoint_path):
    """ 加载模型权重 """
    checkpoint = torch.load(checkpoint_path, map_location='cuda')
    model.load_state_dict(checkpoint['model'])
    print(f"Model loaded from {checkpoint_path}")


def test_model(model, dataloader, cfg):
    """ 测试模型并计算 Dice 指标 """
    model.eval()
    dice_scores = []

    with torch.no_grad():
        for data in dataloader:
            print(f"Data type: {type(data)}")
            print(f"Data content: {data}")
            img, mask = data  # 这是你期望解包的地方
        # for img, mask in dataloader:
            img = img.cuda()
            mask = mask.cuda()

            h, w = img.shape[-2:]
            if img.dim() == 3:
                img = img.unsqueeze(0)  # 添加 batch 维度

            # 确保输入尺寸符合模型要求
            crop_size = cfg['crop_size'] if isinstance(cfg['crop_size'], tuple) else (
            cfg['crop_size'], cfg['crop_size'])
            img = F.interpolate(img, size=crop_size, mode='bilinear', align_corners=False)

            # 进行预测
            pred = model(img)
            pred = pred['out']

            # 还原到原始尺寸
            pred = F.interpolate(pred, size=(h, w), mode='bilinear', align_corners=False)

            # 获取类别预测
            pred = torch.argmax(pred, dim=1)

            pred = pred.cpu().numpy().astype(np.uint8)
            mask = mask.cpu().numpy().astype(np.uint8)

            # 计算 Dice 系数
            intersection = (pred * mask).sum()
            union = pred.sum() + mask.sum()
            dice = 2.0 * intersection / (union + 1e-6)
            dice_scores.append(dice)

    mean_dice = np.mean(dice_scores)
    print(f"Mean Dice Score: {mean_dice:.4f}")
    return mean_dice


def main():
    parser = argparse.ArgumentParser(description="UNet Testing Script")
    parser.add_argument('--config', type=str, default="./configs/acdc.yaml", help="Path to config file")
    parser.add_argument('--checkpoint', type=str, default="./save/acdc/1/best.pth", help="Path to model checkpoint")
    args = parser.parse_args()

    # 读取配置
    cfg = yaml.load(open(args.config, "r"), Loader=yaml.Loader)

    # 加载模型
    model = UNet(in_chns=1, class_num=cfg['nclass'])
    model.cuda()
    load_model(model, args.checkpoint)

    # 加载测试数据集
    testset = ACDCDataset(cfg['dataset'], cfg['data_root'], 'val')
    testloader = DataLoader(testset, batch_size=1, pin_memory=True, num_workers=1, drop_last=False)

    # 运行测试
    test_model(model, testloader, cfg)


if __name__ == '__main__':
    main()
