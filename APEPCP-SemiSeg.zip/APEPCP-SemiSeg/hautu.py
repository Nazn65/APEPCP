import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 生成一个示例相似度矩阵
similarity_matrix = np.random.rand(10, 10)

# 绘制热图
plt.figure(figsize=(8, 6))
sns.heatmap(similarity_matrix, annot=True, cmap='coolwarm', fmt='.2f')
plt.title("Pixel Propagation - Similarity Heatmap")
plt.show()
