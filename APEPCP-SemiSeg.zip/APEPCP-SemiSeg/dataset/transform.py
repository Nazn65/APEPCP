import numpy as np
import random
import torch
from PIL import ImageFilter, Image, ImageEnhance, ImageOps
from scipy import ndimage
from torchvision import transforms
import cv2

def random_rot_flip(img, mask):
    k = np.random.randint(0, 4)
    img = np.rot90(img, k)
    mask = np.rot90(mask, k)
    axis = np.random.randint(0, 2)
    img = np.flip(img, axis=axis).copy()
    mask = np.flip(mask, axis=axis).copy()
    return img, mask

def random_rot_flip2(img, mask, bimask):
    k = np.random.randint(0, 4)
    img = np.rot90(img, k)
    mask = np.rot90(mask, k)
    bimask = np.rot90(bimask, k)
    axis = np.random.randint(0, 2)
    img = np.flip(img, axis=axis).copy()
    mask = np.flip(mask, axis=axis).copy()
    bimask = np.flip(bimask, axis=axis).copy()
    return img, mask, bimask

def random_rot_flip3(img, mask, bimask):
    k = np.random.randint(0, 4)
    img = np.rot90(img, k)
    mask = np.rot90(mask, k)
    # zeros = np.zeros(3, mask.shape[0], mask.shape[1])
    # for i in range(3):
    #     zeros[i] = np.rot90(bimask[i], k)
    rotated_channels = [np.rot90(channel, k) for channel in bimask]
    rotated_array = np.stack(rotated_channels)
    axis = np.random.randint(0, 2)
    img = np.flip(img, axis=axis).copy()
    mask = np.flip(mask, axis=axis).copy()
    flipped_channels_horizontal = [np.flip(channel, axis=axis).copy() for channel in rotated_array]
    flipped_array_horizontal = np.stack(flipped_channels_horizontal)
    return img, mask, flipped_array_horizontal

def random_rotate(img, mask):
    angle = np.random.randint(-20, 20)
    img = ndimage.rotate(img, angle, order=0, reshape=False)
    mask = ndimage.rotate(mask, angle, order=0, reshape=False)
    return img, mask

def random_rotate2(img, mask, bimask):
    angle = np.random.randint(-20, 20)
    img = ndimage.rotate(img, angle, order=0, reshape=False)
    mask = ndimage.rotate(mask, angle, order=0, reshape=False)
    bimask = ndimage.rotate(bimask, angle, order=0, reshape=False)
    return img, mask, bimask

def random_rotate3(img, mask, bimask):
    angle = np.random.randint(-20, 20)
    img = ndimage.rotate(img, angle, order=0, reshape=False)
    mask = ndimage.rotate(mask, angle, order=0, reshape=False)
    # bimask = ndimage.rotate(bimask, angle, order=0, reshape=False)
    rotated_channels = [ndimage.rotate(channel, angle, order=0, reshape=False) for channel in bimask]
    rotated_array = np.stack(rotated_channels)
    return img, mask, rotated_array


def random_crop(image, label, patch_size):
    """
    Crop randomly the image in a sample
    Args:
    patch_size (int): Desired output size
    """
    if label.shape[0] <= patch_size[0] or label.shape[1] <= patch_size[1] or label.shape[2] <= label.shape[2]:
        pw = max((patch_size[0] - label.shape[0]) // 2 + 3, 0)
        ph = max((patch_size[1] - label.shape[1]) // 2 + 3, 0)
        pd = max((patch_size[2] - label.shape[2]) // 2 + 3, 0)
        image = np.pad(image, [(pw, pw), (ph, ph), (pd, pd)], mode='constant', constant_values=0)
        label = np.pad(label, [(pw, pw), (ph, ph), (pd, pd)], mode='constant', constant_values=0)

    (w, h, d) = image.shape

    w1 = np.random.randint(0, w - patch_size[0])
    h1 = np.random.randint(0, h - patch_size[1])
    d1 = np.random.randint(0, d - patch_size[2])

    label = label[w1:w1 + patch_size[0], h1:h1 + patch_size[1], d1:d1 + patch_size[2]]
    image = image[w1:w1 + patch_size[0], h1:h1 + patch_size[1], d1:d1 + patch_size[2]]

    return image, label

def blur(img, p=0.5):
    if random.random() < p:
        sigma = np.random.uniform(0.1, 2.0)
        img = img.filter(ImageFilter.GaussianBlur(radius=sigma))
    return img

def blur2(img, p=0.5):
    temp = []
    if random.random() < p:
        sigma = np.random.uniform(0.1, 2.0)
        for c in img:
            c = c.filter(ImageFilter.GaussianBlur(radius=sigma))
            temp.append(c)
    if len(temp) == 0:
        return img
    return temp

def bilateral_filter(image, labeled=False, diameter=9, sigma_color=0, sigma_space=0):
    # cv_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    img_array = np.array(image)
    if img_array.dtype != np.uint8:
        img_array = (img_array * 255).astype(np.uint8)
    filtered_image = cv2.bilateralFilter(img_array, diameter, sigma_color, sigma_space)
    if not labeled:
        filtered_image = Image.fromarray(filtered_image)
    # output_image = Image.fromarray(cv2.cvtColor(filtered_image, cv2.COLOR_BGR2RGB))
    return filtered_image

def obtain_cutmix_box(img_size, p=0.5, size_min=0.02, size_max=0.4, ratio_1=0.3, ratio_2=1/0.3):
    mask = torch.zeros(img_size, img_size)
    if random.random() > p:
        return mask

    size = np.random.uniform(size_min, size_max) * img_size * img_size
    while True:
        ratio = np.random.uniform(ratio_1, ratio_2)
        cutmix_w = int(np.sqrt(size / ratio))
        cutmix_h = int(np.sqrt(size * ratio))
        x = np.random.randint(0, img_size)
        y = np.random.randint(0, img_size)

        if x + cutmix_w <= img_size and y + cutmix_h <= img_size:
            break

    mask[y:y + cutmix_h, x:x + cutmix_w] = 1

    return mask

# def obtain_cutmix_3Dbox(img_size, p=0.5, size_min=0.02, size_max=0.4, ratio_1=0.3, ratio_2=1/0.3):
#     mask = torch.zeros(img_size[0], img_size[1], img_size[2])
#     if random.random() > p:
#         return mask

#     size = np.random.uniform(size_min, size_max) * img_size[0] * img_size[1]
#     size2 = np.random.uniform(size_min, size_max) * img_size[2] * img_size[2]
#     while True:
#         ratio = np.random.uniform(ratio_1, ratio_2)
#         cutmix_w = int(np.sqrt(size / ratio))
#         cutmix_h = int(np.sqrt(size * ratio))
#         cutmix_d = int(np.cbrt(size2 / (ratio ** 2)))
#         x = np.random.randint(0, img_size[0])
#         y = np.random.randint(0, img_size[1])
#         z = np.random.randint(0, img_size[2])

#         if x + cutmix_w <= img_size[0] and y + cutmix_h <= img_size[1] and z + cutmix_d <= img_size[2]:
#             break

#     mask[y:y + cutmix_h, x:x + cutmix_w, z:z + cutmix_d] = 1

#     return mask

def obtain_cutmix_3Dbox(img_size, p=0.5, size_min=0.02, size_max=0.4, ratio_1=0.3, ratio_2=1/0.3):
    height, width, depth = img_size
    mask = torch.zeros(height, width, depth)
    if random.random() > p:
        return mask

    size = np.random.uniform(size_min, size_max) * height * width * depth
    while True:
        ratio = np.random.uniform(ratio_1, ratio_2)
        cutmix_w = int(np.sqrt(size / ratio / depth))
        cutmix_h = int(np.sqrt(size * ratio / depth))
        cutmix_d = np.random.randint(1, depth)
        x = np.random.randint(0, width)
        y = np.random.randint(0, height)
        z = np.random.randint(0, depth)

        if x + cutmix_w <= width and y + cutmix_h <= height and z + cutmix_d <= depth:
            break

    mask[y:y + cutmix_h, x:x + cutmix_w, z:z + cutmix_d] = 1

    return mask


def img_aug_identity(img, scale=None):
    return img

def img_aug_autocontrast(img, scale=None):
    return ImageOps.autocontrast(img)


def img_aug_equalize(img, scale=None):
    return ImageOps.equalize(img)


def img_aug_invert(img, scale=None):
    return ImageOps.invert(img)


def img_aug_blur(img, scale=[0.1, 2.0]):
    assert scale[0] < scale[1]
    sigma = np.random.uniform(scale[0], scale[1])
    # print(f"sigma:{sigma}")
    return img.filter(ImageFilter.GaussianBlur(radius=sigma))


def img_aug_contrast(img, scale=[0.05, 0.95]):
    min_v, max_v = min(scale), max(scale)
    v = float(max_v - min_v)*random.random()
    v = max_v - v
    # # print(f"final:{v}")
    # v = np.random.uniform(scale[0], scale[1])
    return ImageEnhance.Contrast(img).enhance(v)


def img_aug_brightness(img, scale=[0.05, 0.95]):
    min_v, max_v = min(scale), max(scale)
    v = float(max_v - min_v)*random.random()
    v = max_v - v
    # print(f"final:{v}")
    return ImageEnhance.Brightness(img).enhance(v)


def img_aug_color(img, scale=[0.05, 0.95]):
    min_v, max_v = min(scale), max(scale)
    v = float(max_v - min_v)*random.random()
    v = max_v - v
    # print(f"final:{v}")
    return ImageEnhance.Color(img).enhance(v)


def img_aug_sharpness(img, scale=[0.05, 0.95]):
    min_v, max_v = min(scale), max(scale)
    v = float(max_v - min_v)*random.random()
    v = max_v - v
    # print(f"final:{v}")
    return ImageEnhance.Sharpness(img).enhance(v)


def img_aug_hue(img, scale=[0, 0.5]):
    min_v, max_v = min(scale), max(scale)
    v = float(max_v - min_v)*random.random()
    v += min_v
    if np.random.random() < 0.5:
        hue_factor = -v
    else:
        hue_factor = v
    # print(f"Final-V:{hue_factor}")
    input_mode = img.mode
    if input_mode in {"L", "1", "I", "F"}:
        return img
    h, s, v = img.convert("HSV").split()
    np_h = np.array(h, dtype=np.uint8)
    # uint8 addition take cares of rotation across boundaries
    with np.errstate(over="ignore"):
        np_h += np.uint8(hue_factor * 255)
    h = Image.fromarray(np_h, "L")
    img = Image.merge("HSV", (h, s, v)).convert(input_mode)
    return img


def img_aug_posterize(img, scale=[4, 8]):
    min_v, max_v = min(scale), max(scale)
    v = float(max_v - min_v)*random.random()
    # print(min_v, max_v, v)
    v = int(np.ceil(v))
    v = max(1, v)
    v = max_v - v
    # print(f"final:{v}")
    return ImageOps.posterize(img, v)


def img_aug_solarize(img, scale=[1, 256]):
    min_v, max_v = min(scale), max(scale)
    v = float(max_v - min_v)*random.random()
    # print(min_v, max_v, v)
    v = int(np.ceil(v))
    v = max(1, v)
    v = max_v - v
    # print(f"final:{v}")
    return ImageOps.solarize(img, v)

def get_augment_list(flag_using_wide=False):  
    if flag_using_wide:
        l = [
        (img_aug_identity, None),
        (img_aug_autocontrast, None),
        (img_aug_equalize, None),
        (img_aug_blur, [0.1, 2.0]),
        (img_aug_contrast, [0.1, 1.8]),
        (img_aug_brightness, [0.1, 1.8]),
        (img_aug_color, [0.1, 1.8]),
        (img_aug_sharpness, [0.1, 1.8]),
        (img_aug_posterize, [2, 8]),
        (img_aug_solarize, [1, 256]),
        (img_aug_hue, [0, 0.5])
        ]
    else:
        l = [
            (img_aug_identity, None),
            (img_aug_autocontrast, None),
            (img_aug_equalize, None),
            (img_aug_blur, [0.1, 2.0]),
            (img_aug_contrast, [0.05, 0.95]),
            (img_aug_brightness, [0.05, 0.95]),
            (img_aug_color, [0.05, 0.95]),
            (img_aug_sharpness, [0.05, 0.95]),
            (img_aug_posterize, [4, 8]),
            (img_aug_solarize, [1, 256]),
            (img_aug_hue, [0, 0.5])
        ]
    return l


class strong_img_aug:
    def __init__(self, num_augs, flag_using_random_num=False):
        assert 1<= num_augs <= 11
        self.n = num_augs
        self.augment_list = get_augment_list(flag_using_wide=False)
        self.flag_using_random_num = flag_using_random_num
    
    def __call__(self, img):
        if self.flag_using_random_num:
            max_num = np.random.randint(1, high=self.n + 1)
        else:
            max_num =self.n
        ops = random.choices(self.augment_list, k=max_num)
        for op, scales in ops:
            img = op(img, scales)
        return img



